# Interviewwerkruimte

Een klein ICM-voorbeeld. Het zet een interviewtranscript om in nette bevindingen, één stage per keer.

Gebruik:
1. Open deze map in de assistent die je gebruikt (of upload de bestanden als die geen map kan lezen).
2. Zet een transcript in `bronnen/`, bijvoorbeeld `bronnen/interview-01.md`.
3. Zeg: "Verwerk het interview in bronnen/interview-01.md."
4. Lees na elke stage wat er gemaakt is en corrigeer het voor je verdergaat.

Pas aan wat niet bij je werk past. Deze bestanden zijn gewone tekst.
