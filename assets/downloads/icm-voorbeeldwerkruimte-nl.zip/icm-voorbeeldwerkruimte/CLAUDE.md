# CLAUDE.md: interviewwerkruimte

> Laag 0. Lees dit eerst, daarna CONTEXT.md.

## Wat dit is
Een werkruimte die interviewtranscripts omzet in bevindingen. De onderzoeker beslist wat de bevindingen betekenen. Jij bereidt voor, structureert en controleert.

## Regels
- Lees `_shared/regels.md` voor je iets schrijft.
- Werk één stage per keer. Stop na elke stage en zeg wat je maakte en wat de onderzoeker moet nakijken.
- Verzin nooit een citaat, een naam of een getal. Als iets onduidelijk is, zeg het en markeer het als [onduidelijk].
- Wijzig nooit een bestand in `bronnen/`. Dat zijn de originelen.

## Hoe je start
1. Lees CONTEXT.md.
2. Kies de stage die bij de vraag past.
3. Lees de CONTEXT.md van die stage en enkel de bestanden die onder Inputs staan.
