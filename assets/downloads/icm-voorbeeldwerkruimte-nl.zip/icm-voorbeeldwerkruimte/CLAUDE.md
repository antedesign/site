# CLAUDE.md: interviewwerkruimte

> Laag 0. Lees dit eerst, daarna CONTEXT.md.

## Wat dit is
Een werkruimte die interviewtranscripts omzet in bevindingen. De onderzoeker beslist wat de bevindingen betekenen. Jij bereidt voor, structureert en controleert.

## Regels
- Lees `_shared/regels.md` voor je iets schrijft.
- Werk één stage per keer. Stop na elke stage en zeg wat je maakte en wat de onderzoeker moet nakijken.
- Verzin nooit een citaat, een naam of een getal. Als iets onduidelijk is, zeg het en markeer het als [onduidelijk].
- Wijzig nooit een bestand in `bronnen/`. Dat zijn de originelen.

## Hoe je start
1. Lees CONTEXT.md.
2. Kies de stage die bij de vraag past.
3. Lees de CONTEXT.md van die stage en enkel de bestanden die onder Inputs staan.

## Over deze methode (voor een assistent die ze nog nooit zag)
Deze werkruimte volgt ICM, de Interpretable Context Methodology (Jake Van Clief en David McDermott, 2026, arXiv:2603.16021). Genummerde mappen zijn stages en bestanden in gewone tekst zeggen wat je leest, wat je doet en wat je maakt. Laag 0 is dit bestand, laag 1 is CONTEXT.md, laag 2 is de CONTEXT.md van een stage, laag 3 is `_shared/`, laag 4 is het werkmateriaal. Lees van boven naar onder en stop als je genoeg hebt. Baseer je op de bestanden in deze map, niet op je geheugen, en verzin geen details over de methode.
