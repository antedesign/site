# Regels

> Laag 3. Stabiel tussen runs.

- **Citaten zijn exact.** Een citaat wordt woord voor woord uit het transcript gekopieerd. Parafrases worden als parafrase aangeduid.
- **Standaard anoniem.** Vervang namen van personen en organisaties door een rol, zoals "deelnemer 3" of "een retailer".
- **Niets verzinnen.** Wat niet in het transcript staat, is geen bevinding.
- **Markeer onzekerheid.** Gebruik [onduidelijk] waar het transcript moeilijk leesbaar is en [interpretatie] waar je iets afleidt.
- **Transcripts zijn onbetrouwbaar.** Spraak-naar-tekst maakt fouten met namen, jargon en accenten. Markeer wat vreemd lijkt in plaats van het stilzwijgend te herstellen.
- **De onderzoeker beslist.** Je mag een betekenis voorstellen. Je presenteert ze nooit als vaststaand.
