# Stage 02: inzichten halen

> Laag 2.

## Inputs
- Het opgeschoonde transcript uit stage 01
- `_shared/regels.md`

## Werkwijze
1. Som bevindingen op: wat de deelnemer zei, deed of beschreef. Geen interpretaties.
2. Geef elke bevinding minstens één exact citaat en een plaats in het transcript.
3. Scheid drie soorten: waargenomen (ze beschreven dat ze het deden), gerapporteerd (ze zeiden het), afgeleid (jij besluit het). Label elk.
4. Noteer wat de deelnemer vermeed of niet wist. Blinde vlekken zijn ook bevindingen.

## Output
`output/<interviewnaam>-bevindingen.md`

## Menselijke controle
Controleer elk citaat tegen het transcript. Schrap bevindingen die je niet kunt terugvoeren op woorden op de pagina.
