# Stage 03: groeperen

> Laag 2.

## Inputs
- Alle bevindingenbestanden in `stages/02-inzichten-halen/output/`
- `_shared/regels.md`

## Werkwijze
1. Groepeer bevindingen die hetzelfde zeggen in andere woorden. Geef elke groep een korte naam.
2. Tel in hoeveel interviews elke groep terugkomt. Tel dezelfde deelnemer niet twee keer.
3. Som bevindingen op die in geen groep passen. Forceer niets.
4. Som op wat de interviews niet behandelden, als vragen voor het volgende gesprek.

## Output
`output/groepen.md`

## Menselijke controle
Heb je de interviews zelf gelezen? Groeperen is een eerste ronde. Verplaats, voeg samen en hernoem groepen tot ze overeenkomen met wat je zag.
