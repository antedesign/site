# Stage 01: transcript opschonen

> Laag 2. Eén stage, één taak.

## Inputs
- Het transcript uit de vraag, uit `bronnen/`
- `_shared/regels.md`

## Werkwijze
1. Markeer sprekers consistent, bijvoorbeeld "Interviewer" en "Deelnemer".
2. Herstel duidelijke typ- en spraak-naar-tekstfouten. Behoud de formulering van de deelnemer.
3. Vervang namen door rollen, volgens de regels.
4. Som bovenaan alles op wat fout of onduidelijk lijkt, onder "Na te kijken".

## Output
`output/<interviewnaam>-schoon.md`

## Menselijke controle
Lees de lijst "Na te kijken" en het transcript naast elkaar. Bevestig dat niets betekenisvols veranderd is.
