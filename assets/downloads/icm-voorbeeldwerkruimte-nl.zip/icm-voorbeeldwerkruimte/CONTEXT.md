# CONTEXT.md: router

> Laag 1. Welke stage voor welke vraag.

| Als de vraag is | Ga naar |
|---|---|
| "Maak het transcript schoon" of "verwerk het interview" (eerste stap) | `stages/01-transcript-opschonen/CONTEXT.md` |
| "Zoek de inzichten" of "wat zeiden ze" | `stages/02-inzichten-halen/CONTEXT.md` |
| "Groepeer de bevindingen" of "vergelijk de interviews" | `stages/03-groeperen/CONTEXT.md` |

"Verwerk het interview" betekent stage 01, 02 en 03 in volgorde, met een stop na elke stage.
