# Voorbeeld van een ICM-mappenstructuur

Fictief voorbeeld. Geen echte personen of gegevens.

## Zo probeer je het

1. Pak de zip uit en open de map `Unief` in een AI-tool die mappen kan lezen (bijvoorbeeld Claude Desktop of Claude Code).
2. Werkt jouw tool het bestand `CLAUDE.md` niet vanzelf in? Begin dan met: "Lees eerst CLAUDE.md."
3. Probeer een van deze zinnen:
   - "Verwerk dit interview voor productenanalyse." (zet eerst een transcript in `Transcripts/`, of gebruik het voorbeeld dat er al staat)
   - "Leer de huisstijl en schrijf de designbrief." (zet eerst 2 of 3 voorbeeldslides in `1 Inspiratie/`) en daarna "Maak een presentatie over [onderwerp] in de mijn-huisstijl."
   - "Toon de blinde vlekken in mijn onderzoek voor duurzaam ontwerp."

## Hoe het werkt

De AI leest eerst `CLAUDE.md`. Dat bestand zegt naar welke map hij moet. In die map staat een `CONTEXT.md` met zijn rol, zijn stappen en de regels. Hij leest alleen de bestanden van die ene taak.

## Je eigen versie maken

Bouw je eigen versie niet met de hand. Gebruik `startersprompt.md`: plak de tekst in je AI en laat je stap voor stap begeleiden.
