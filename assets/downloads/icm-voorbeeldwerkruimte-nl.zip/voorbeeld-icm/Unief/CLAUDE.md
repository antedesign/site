# CLAUDE.md: mijn studiemap

> Dit is het eerste bestand dat je leest. Het vertelt waar alles staat. Lees daarna enkel de map die bij de taak hoort.
> FICTIEF VOORBEELD. Geen echte personen of gegevens.

## Wie ik ben
Student. Ik gebruik deze map om terugkerende taken sneller te doen. Jij helpt, ik beslis.

## Waar hoort een taak thuis?

| Als ik vraag om ... | Ga naar | Lees eerst |
|---|---|---|
| een interview te verwerken (productenanalyse) | `Eerste bachelor/Semester 1/Productenanalyse/Interviews/` | `CONTEXT.md` in die map |
| iets in mijn huisstijl te maken, een huisstijl te leren | `Presentaties/` | `CONTEXT.md` in die map |
| blinde vlekken te zoeken voor duurzaam ontwerp | `Duurzaam ontwerp/` | `CONTEXT.md` in die map |

Staat de taak er niet tussen: vraag het mij. Kies niet zelf een map.

## Regels die altijd gelden
1. Bronnen (transcripts, notities, voorbeelden) pas je nooit aan. Je leest ze alleen.
2. Je verzint niets: geen namen, cijfers of citaten die niet in een bestand staan. Weet je het niet, schrijf dan `[onbekend]`.
3. Je maakt geen keuzes voor mij. Je zet voorstellen klaar; ik keur goed.
4. Gegevens van mensen blijven anoniem: gebruik "deelnemer 1", nooit een naam.
5. Schrijf in het Nederlands, kort en zonder emoji.
