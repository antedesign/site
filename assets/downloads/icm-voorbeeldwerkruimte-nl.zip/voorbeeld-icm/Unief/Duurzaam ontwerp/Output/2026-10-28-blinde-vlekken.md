# Blinde vlekken: herbruikbare lunchbox  ·  2026-10-28

> FICTIEF VOORBEELD. Gemaakt volgens `Instructies/blinde-vlekken.md`.

## Balans
| Map | Bestanden |
|---|---|
| Interviews | 4 |
| Brainstorms | 2 |
| Desk research | 1 |
| Menskundige analyse | 1 |
| Markt en business | 1 (bijna leeg) |

## Blinde vlekken, geclusterd per thema

**Thema 1: gebruik op lange termijn**
1. Alle interviews gaan over dagelijks gebruik nu. Niemand vertelt wat er na een jaar gebeurt (zie `Interviews/deelnemer-04.md`: enkel een vervormd deksel).
2. De desk research noemt levensduur, maar er is geen gegeven over hoe lang studenten een lunchbox houden.

**Thema 2: markt**
1. `Markt en business/` bevat enkel 3 merknamen, geen prijzen of verkoopkanalen.

**Thema 3: standpunten**
1. Alle stemmen komen van gebruikers. Het standpunt van wie afwast (vaatwasser, refter) of wie verkoopt ontbreekt.

## Vragen voor het team
1. Willen we weten hoe lang een lunchbox in gebruik blijft?
2. Wie spreken we voor de markt?
3. Is het standpunt van de refter relevant voor dit project?
