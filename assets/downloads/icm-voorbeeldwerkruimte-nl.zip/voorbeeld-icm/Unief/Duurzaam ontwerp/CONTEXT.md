# Duurzaam ontwerp

> Project: herbruikbare lunchbox voor studenten. Fictief voorbeeld.

## Mappen
| Map | Wat erin zit |
|---|---|
| `Context/` | alles wat we verzamelden, per soort: desk research, markt en business, menskundige analyse, interviews, brainstorms |
| `Instructies/` | hoe een analyse moet gebeuren |
| `Output/` | resultaten van analyses, met datum |

## Taken
| Als ik vraag om ... | Lees |
|---|---|
| blinde vlekken te tonen | `Instructies/blinde-vlekken.md` |
