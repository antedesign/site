# Desk research: levensduur van herbruikbare verpakking

> FICTIEF. Samenvatting van 2 artikels over hoe vaak je een herbruikbaar product moet gebruiken voor het beter scoort dan wegwerp.
