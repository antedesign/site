# Menskundige analyse: grip en openen

> FICTIEF. Observatie van 3 deelnemers die de lunchbox openen. Kracht en handpositie.
