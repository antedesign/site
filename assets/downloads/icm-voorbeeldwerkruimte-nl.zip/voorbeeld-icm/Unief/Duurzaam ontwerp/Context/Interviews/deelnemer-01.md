# Interview deelnemer 01

> FICTIEF. Deksel lekt, gebruiker steekt de lunchbox in een plastic zakje. Rubberen rand moeilijk proper.
