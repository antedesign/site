# Interview deelnemer 02

> FICTIEF. Gebruikt de lunchbox 3 keer per week. Vindt hem te zwaar met glas erin.
