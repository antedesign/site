# Interview deelnemer 04

> FICTIEF. Wast hem in de vaatwasser; het deksel is vervormd.
