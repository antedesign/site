# Brainstorm 2: materialen

> FICTIEF. Glas, roestvrij staal, bamboevezel, gerecycleerd PP.
