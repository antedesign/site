# Brainstorm 1: deksels

> FICTIEF. 14 ideeën voor een deksel dat hoorbaar klikt.
