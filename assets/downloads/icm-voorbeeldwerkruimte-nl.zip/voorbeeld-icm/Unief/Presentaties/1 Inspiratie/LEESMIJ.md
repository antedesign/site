# Inspiratie

Zet hier voorbeelden van de stijl die je wil: screenshots, een PDF of een PowerPoint.
Weet je precies wat je wil, dan volstaat één bestand.

(In dit voorbeeld staan geen echte bestanden. Sleep er zelf 2 of 3 slides in en zeg: "Leer de huisstijl en schrijf de designbrief.")
