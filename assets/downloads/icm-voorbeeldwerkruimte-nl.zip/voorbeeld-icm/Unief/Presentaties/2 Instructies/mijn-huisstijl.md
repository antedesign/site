# Designbrief: mijn-huisstijl

> Opgesteld uit `1 Inspiratie/`. Fictief voorbeeld.

## Formaat
16:9, 1920 x 1080.

## Kleuren
| Rol | Kleur |
|---|---|
| Band bovenaan, hoofdstukvlak | `#9ec4d3` lichtblauw |
| Tekst | `#003366` donkerblauw |
| Kaarten en vlakken | `#e6f0f5` heel lichtblauw |
| Achtergrond | `#ffffff` wit |

## Opbouw van een gewone slide
1. Lichtblauwe band bovenaan met de titel in wit, vet.
2. Daaronder één ondertitel in donkerblauw, vet.
3. Daaronder het visuele deel: kaarten, een tijdlijn, een beeld. Weinig tekst.
4. Logo linksonder, paginanummer rechtsonder.

## Hoofdstukslide
Groot lichtblauw vlak met afgeronde hoek linksonder, titel groot en wit in het midden, eronder het hoofdstuk in hoofdletters.

## Regels
1. Eén boodschap per slide.
2. Cijfers in cijfers.
3. Geen emoji, geen schaduwen, geen verlopen.
