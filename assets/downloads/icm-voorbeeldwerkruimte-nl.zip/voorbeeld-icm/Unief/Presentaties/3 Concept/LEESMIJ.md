# Concept

Hier komt het resultaat: de presentatie die de AI maakt volgens `2 Instructies/`. Jij bewerkt en keurt goed.
