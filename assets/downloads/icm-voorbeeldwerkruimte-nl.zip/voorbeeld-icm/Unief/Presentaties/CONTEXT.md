# Presentaties

> Instructies voor alles wat visueel in een vaste stijl moet. Fictief voorbeeld.

## Mappen
| Map | Wat erin zit | Wie schrijft |
|---|---|---|
| `1 Inspiratie/` | voorbeelden van de stijl: foto's, PDF, PowerPoint | ik |
| `2 Instructies/` | de designbrief per stijl, bijvoorbeeld `mijn-huisstijl.md` | jij, ik keur goed |
| `3 Concept/` | het resultaat: een nieuw concept | jij |

## Taak A: "leer de <naam> en schrijf de designbrief"
1. Bekijk alles in `1 Inspiratie/`.
2. Beschrijf de stijl als regels: kleuren (met hexcode), lettertypes en groottes, opbouw van een slide, wat nooit mag.
3. Bewaar als `2 Instructies/<naam>.md`. De naam is hoe ik de stijl voortaan noem.
4. Kies niets wat niet in de voorbeelden staat. Twijfel: zet het als vraag onderaan.

## Taak B: "maak een presentatie over <onderwerp> in de <naam>"
1. Lees `2 Instructies/<naam>.md`. Bestaat die niet: stop en vraag het.
2. Maak een concept in `3 Concept/`: één boodschap per slide, eerst een opbouw (titels), dan de slides.
3. Laat plaats voor beelden met een duidelijke placeholder.
4. De inhoud bepaal ik. Jij past enkel de stijl en de opbouw toe.
