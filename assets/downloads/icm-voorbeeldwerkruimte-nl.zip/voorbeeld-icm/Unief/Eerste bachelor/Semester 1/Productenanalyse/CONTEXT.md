# Productenanalyse

> Vak in semester 1. Fictief voorbeeld.

Wat hier gebeurt: we analyseren een bestaand product. Interviews met gebruikers horen daarbij.

| Map | Waarvoor |
|---|---|
| `Interviews/` | interviews verwerken: transcript bewaren en een one-pager maken |

Ga voor een interview naar `Interviews/CONTEXT.md`.
