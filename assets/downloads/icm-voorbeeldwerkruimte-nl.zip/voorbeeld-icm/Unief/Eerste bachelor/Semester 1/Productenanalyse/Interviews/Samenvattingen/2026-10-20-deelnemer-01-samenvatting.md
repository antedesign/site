# Interview deelnemer 01: herbruikbare lunchbox  ·  2026-10-20

> FICTIEF VOORBEELD. Gemaakt volgens `Interviews/CONTEXT.md`.

**Wie en context**
Student die de lunchbox bijna elke dag gebruikt, behalve op vrijdag. Interview op de campus, in de refter.

**3 kernpunten**
1. Het deksel sluit niet altijd goed. "Dat klikt niet altijd goed dicht."
2. Als oplossing gebruikt de deelnemer opnieuw plastic. "Nu steek ik hem in een plastic zakje."
3. De rubberen rand is moeilijk proper te krijgen. "In die rubberen rand blijft vuil zitten."

**Vervolgstappen**
1. Nagaan bij andere deelnemers of het deksel vaker lekt.
2. Testen of een hoorbare klik het vertrouwen verhoogt.
3. De rubberen rand bekijken: afneembaar of anders vormgegeven?

*Na te kijken door de student: kernpunten en vervolgstappen.*
