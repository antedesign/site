# Example of an ICM folder structure

Fictional example. No real people or data.

## How to try it

1. Unzip the file and open the `University` folder in an AI tool that can read folders (for example Claude Desktop or Claude Code).
2. Does your tool not load `CLAUDE.md` by itself? Then start with: "Read CLAUDE.md first."
3. Try one of these sentences:
   - "Process this interview for product analysis." (first put a transcript in `Transcripts/`, or use the example that is already there)
   - "Learn the house style and write the design brief." (first put 2 or 3 example slides in `1 Inspiration/`) and then "Make a presentation about [topic] in my-style."
   - "Show the blind spots in my research for sustainable design."

## How it works

The AI reads `CLAUDE.md` first. That file says which folder to go to. In that folder is a `CONTEXT.md` with its role, its steps and the rules. It reads only the files of that one task.

## Make your own version

Do not build your own version by hand. Use `starter-prompt.md`: paste the text into your AI and let it guide you step by step.
