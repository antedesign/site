# Presentations

> Instructions for everything visual that must follow a fixed style. Fictional example.

## Folders
| Folder | What is in it | Who writes |
|---|---|---|
| `1 Inspiration/` | examples of the style: photos, PDF, PowerPoint | me |
| `2 Instructions/` | the design brief per style, for example `my-style.md` | you, I approve |
| `3 Concept/` | the result: a new concept | you |

## Task A: "learn the <name> and write the design brief"
1. Look at everything in `1 Inspiration/`.
2. Describe the style as rules: colours (with hex code), fonts and sizes, how a slide is built, what is never allowed.
3. Save as `2 Instructions/<name>.md`. The name is how I will call the style from now on.
4. Choose nothing that is not in the examples. In doubt: put it as a question at the bottom.

## Task B: "make a presentation about <topic> in the <name>"
1. Read `2 Instructions/<name>.md`. If it does not exist: stop and ask.
2. Make a concept in `3 Concept/`: one message per slide, first an outline (titles), then the slides.
3. Leave room for images with a clear placeholder.
4. I decide the content. You only apply the style and the structure.
