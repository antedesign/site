# Design brief: my-style

> Written from `1 Inspiration/`. Fictional example.

## Format
16:9, 1920 x 1080.

## Colours
| Role | Colour |
|---|---|
| Band at the top, chapter shape | `#9ec4d3` light blue |
| Text | `#003366` dark blue |
| Cards and shapes | `#e6f0f5` very light blue |
| Background | `#ffffff` white |

## Build of a normal slide
1. A light blue band at the top with the title in white, bold.
2. Below it one subtitle in dark blue, bold.
3. Below that the visual part: cards, a timeline, an image. Little text.
4. Logo bottom left, page number bottom right.

## Chapter slide
A large light blue shape with a rounded corner at the bottom left, the title large and white in the middle, the chapter below it in capitals.

## Rules
1. One message per slide.
2. Numbers as digits.
3. No emoji, no shadows, no gradients.
