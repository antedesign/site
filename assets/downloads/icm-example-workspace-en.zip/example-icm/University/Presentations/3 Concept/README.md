# Concept

The result goes here: the presentation the AI makes following `2 Instructions/`. You edit and approve.
