# CLAUDE.md: my study folder

> This is the first file you read. It tells you where everything is. After that, read only the folder that belongs to the task.
> FICTIONAL EXAMPLE. No real people or data.

## Who I am
A student. I use this folder to do repeating tasks faster. You help, I decide.

## Where does a task belong?

| When I ask for ... | Go to | Read first |
|---|---|---|
| processing an interview (product analysis) | `First year/Semester 1/Product analysis/Interviews/` | `CONTEXT.md` in that folder |
| making something in my style, or learning a style | `Presentations/` | `CONTEXT.md` in that folder |
| finding blind spots for sustainable design | `Sustainable design/` | `CONTEXT.md` in that folder |

If the task is not in this list: ask me. Do not pick a folder yourself.

## Rules that always apply
1. Never change sources (transcripts, notes, examples). You only read them.
2. Invent nothing: no names, numbers or quotes that are not in a file. If you do not know, write `[unknown]`.
3. Do not make choices for me. You prepare proposals; I approve.
4. Information about people stays anonymous: write "participant 1", never a name.
5. Write in English, short, without emoji.
