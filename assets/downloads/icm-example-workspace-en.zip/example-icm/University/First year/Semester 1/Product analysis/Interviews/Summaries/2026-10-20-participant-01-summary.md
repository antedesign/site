# Interview participant 01: reusable lunchbox  ·  2026-10-20

> FICTIONAL EXAMPLE. Made following `Interviews/CONTEXT.md`.

**Who and context**
A student who uses the lunchbox almost every day, except on Friday. Interview on campus, in the canteen.

**3 key points**
1. The lid does not always close properly. "It does not always click shut properly."
2. As a fix, the participant uses plastic again. "Now I put it in a plastic bag."
3. The rubber rim is hard to get clean. "Dirt stays in that rubber rim."

**Next steps**
1. Check with other participants whether the lid leaks more often.
2. Test whether an audible click raises trust.
3. Look at the rubber rim: removable or shaped differently?

*To be checked by the student: key points and next steps.*
