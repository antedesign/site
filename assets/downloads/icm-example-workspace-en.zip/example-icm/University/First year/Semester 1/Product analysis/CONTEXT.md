# Product analysis

> A course in semester 1. Fictional example.

What happens here: we analyse an existing product. Interviews with users are part of it.

| Folder | What for |
|---|---|
| `Interviews/` | processing interviews: keep the transcript and make a one-pager |

For an interview, go to `Interviews/CONTEXT.md`.
