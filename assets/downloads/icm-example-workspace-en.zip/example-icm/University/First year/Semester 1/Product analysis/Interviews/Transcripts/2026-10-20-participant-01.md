# Transcript interview participant 01

> FICTIONAL EXAMPLE. An invented conversation, not a real person.
> Product: reusable lunchbox. Place: campus canteen. Length: about 12 minutes.

**Interviewer:** How often do you use your lunchbox?
**Participant:** Almost every day. Only not on Friday, then I eat at home.

**Interviewer:** What do you notice when you use it?
**Participant:** The lid. It does not always click shut properly. I have had soup in my backpack once.

**Interviewer:** What did you do then?
**Participant:** Now I put it in a plastic bag. Which is a bit silly, because that is exactly why I bought a reusable one.

**Interviewer:** And washing it?
**Participant:** That is fine. But dirt stays in that rubber rim. I cannot get it out.

**Interviewer:** What would you change?
**Participant:** A lid that you can hear click. Then you know it is shut.

**Interviewer:** Anything else?
**Participant:** It is a bit big for my backpack. But that is not a problem.
