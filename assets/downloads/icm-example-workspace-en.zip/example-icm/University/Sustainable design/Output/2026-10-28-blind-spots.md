# Blind spots: reusable lunchbox  ·  2026-10-28

> FICTIONAL EXAMPLE. Made following `Instructions/blind-spots.md`.

## Balance
| Folder | Files |
|---|---|
| Interviews | 4 |
| Brainstorms | 2 |
| Desk research | 1 |
| Human factors | 1 |
| Market and business | 1 (almost empty) |

## Blind spots, clustered by theme

**Theme 1: long-term use**
1. All interviews are about daily use right now. Nobody says what happens after a year (see `Interviews/participant-04.md`: only a deformed lid).
2. The desk research mentions lifespan, but there is no data on how long students keep a lunchbox.

**Theme 2: market**
1. `Market and business/` contains only 3 brand names, no prices or sales channels.

**Theme 3: points of view**
1. All voices come from users. The point of view of whoever does the washing up (dishwasher, canteen) or whoever sells is missing.

## Questions for the team
1. Do we want to know how long a lunchbox stays in use?
2. Who do we talk to for the market?
3. Is the canteen's point of view relevant for this project?
