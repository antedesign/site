# Sustainable design

> Project: a reusable lunchbox for students. Fictional example.

## Folders
| Folder | What is in it |
|---|---|
| `Context/` | everything we collected, by kind: desk research, market and business, human factors, interviews, brainstorms |
| `Instructions/` | how an analysis must be done |
| `Output/` | results of analyses, with a date |

## Tasks
| When I ask for ... | Read |
|---|---|
| showing blind spots | `Instructions/blind-spots.md` |
