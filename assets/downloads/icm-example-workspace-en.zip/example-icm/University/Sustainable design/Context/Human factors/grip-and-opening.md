# Human factors: grip and opening

> FICTIONAL. Observation of 3 participants opening the lunchbox. Force and hand position.
