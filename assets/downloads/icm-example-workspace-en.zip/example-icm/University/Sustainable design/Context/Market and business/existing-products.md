# Market and business

> FICTIONAL. Still empty: only a list of 3 existing brands, without prices.
