# Desk research: lifespan of reusable packaging

> FICTIONAL. Summary of 2 articles on how often you must use a reusable product before it scores better than disposable.
