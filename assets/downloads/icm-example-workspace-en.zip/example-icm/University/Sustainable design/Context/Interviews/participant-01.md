# Interview participant 01

> FICTIONAL. Lid leaks, the user puts the lunchbox in a plastic bag. Rubber rim hard to clean.
