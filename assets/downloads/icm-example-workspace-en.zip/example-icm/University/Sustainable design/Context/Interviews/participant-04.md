# Interview participant 04

> FICTIONAL. Washes it in the dishwasher; the lid is deformed.
