# Interview participant 02

> FICTIONAL. Uses the lunchbox 3 times a week. Finds it too heavy with glass in it.
