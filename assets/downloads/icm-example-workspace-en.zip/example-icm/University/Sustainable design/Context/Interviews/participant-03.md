# Interview participant 03

> FICTIONAL. Often forgets it on campus. Wants a name label.
