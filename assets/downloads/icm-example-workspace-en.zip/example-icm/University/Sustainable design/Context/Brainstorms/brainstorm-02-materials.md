# Brainstorm 2: materials

> FICTIONAL. Glass, stainless steel, bamboo fibre, recycled PP.
