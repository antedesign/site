# Brainstorm 1: lids

> FICTIONAL. 14 ideas for a lid that clicks audibly.
