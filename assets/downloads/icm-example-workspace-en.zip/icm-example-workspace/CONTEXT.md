# CONTEXT.md: router

> Layer 1. Which stage for which request.

| If the request is | Go to |
|---|---|
| "Clean the transcript" or "process the interview" (first step) | `stages/01-clean-transcript/CONTEXT.md` |
| "Find the insights" or "what did they say" | `stages/02-extract-insights/CONTEXT.md` |
| "Group the findings" or "compare the interviews" | `stages/03-cluster/CONTEXT.md` |

"Process the interview" means stages 01, 02 and 03 in order, with a stop after each.
