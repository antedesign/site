# Interview workspace

A small ICM example. It turns an interview transcript into clean findings, one stage at a time.

How to use it:
1. Open this folder in the assistant you use (or upload the files if it cannot read a folder).
2. Put a transcript in `sources/`, for example `sources/interview-01.md`.
3. Say: "Process the interview in sources/interview-01.md."
4. After each stage, read what was produced and correct it before you go on.

Change anything that does not fit your work. These files are plain text.
