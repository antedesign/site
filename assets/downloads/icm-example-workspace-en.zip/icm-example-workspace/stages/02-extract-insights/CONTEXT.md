# Stage 02: extract insights

> Layer 2.

## Inputs
- The cleaned transcript from stage 01
- `_shared/rules.md`

## Process
1. List findings: things the participant said, did or described. Not interpretations.
2. Give each finding at least one exact quote and a location in the transcript.
3. Separate three kinds: observed (they described doing it), reported (they said it), inferred (you conclude it). Label each.
4. Note anything the participant avoided or did not know. Blind spots are findings too.

## Outputs
`output/<interview-name>-findings.md`

## Human check
Check each quote against the transcript. Delete findings you cannot trace to words on the page.
