# Stage 03: cluster

> Layer 2.

## Inputs
- All findings files in `stages/02-extract-insights/output/`
- `_shared/rules.md`

## Process
1. Group findings that say the same thing in different words. Name each group in a short phrase.
2. Count how many interviews support each group. Do not count the same participant twice.
3. List findings that fit no group. Do not force them.
4. List what the interviews did not cover, as questions for the next conversation.

## Outputs
`output/clusters.md`

## Human check
Have you read the interviews yourself? Clustering is a first pass. Move, merge and rename groups until they match what you saw.
