# Stage 01: clean the transcript

> Layer 2. One stage, one job.

## Inputs
- The transcript named in the request, from `sources/`
- `_shared/rules.md`

## Process
1. Mark speakers consistently, for example "Interviewer" and "Participant".
2. Fix obvious typing and speech-to-text errors. Keep the participant's wording.
3. Replace names with roles, following the rules.
4. List everything that looks wrong or unclear at the top, under "To check".

## Outputs
`output/<interview-name>-clean.md`

## Human check
Read the "To check" list and the transcript side by side. Confirm that nothing meaningful was changed.
