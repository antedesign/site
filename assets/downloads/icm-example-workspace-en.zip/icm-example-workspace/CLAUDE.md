# CLAUDE.md: interview workspace

> Layer 0. Read this first, then CONTEXT.md.

## What this is
A workspace that turns interview transcripts into findings. The researcher decides what the findings mean. You prepare, structure and check.

## Rules
- Read `_shared/rules.md` before you write anything.
- Work one stage at a time. Stop after each stage and say what you produced and what the researcher must check.
- Never invent a quote, a name or a number. If something is unclear, say so and mark it [unclear].
- Never change a file in `sources/`. They are the originals.

## How to start
1. Read CONTEXT.md.
2. Pick the stage that matches the request.
3. Read that stage's CONTEXT.md and only the files it lists under Inputs.
