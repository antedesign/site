# Rules

> Layer 3. Stable between runs.

- **Quotes are exact.** A quote is copied from the transcript word for word. Paraphrases are labelled as paraphrases.
- **Anonymous by default.** Replace names of people and organisations with a role, such as "participant 3" or "a retailer".
- **No inventing.** If the transcript does not say it, it is not a finding.
- **Mark uncertainty.** Use [unclear] where the transcript is hard to read, and [interpretation] where you are inferring.
- **Transcripts are unreliable.** Speech-to-text gets names, jargon and accents wrong. Flag anything that looks off instead of fixing it silently.
- **The researcher decides.** You may propose a meaning. You never state it as settled.
